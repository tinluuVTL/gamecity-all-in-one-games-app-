-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 03, 2021 at 09:36 AM
-- Server version: 10.3.31-MariaDB-cll-lve
-- PHP Version: 7.3.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `youthdea_games`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_action`
--

CREATE TABLE `tbl_action` (
  `cid` int(11) NOT NULL,
  `action_link` varchar(2000) NOT NULL,
  `action_logo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_action`
--

INSERT INTO `tbl_action` (`cid`, `action_link`, `action_logo`) VALUES
(140, 'https://www.yad.com/games/Object-Hunt/', 'https://play.youthdeal.net/games/upload/7300-2021-11-01.jpg'),
(141, 'https://www.yad.com/games/Defense-Battle/', 'https://play.youthdeal.net/games/upload/1306-2021-11-01.jpg'),
(142, 'https://www.yad.com/games/Stop-Them-All/', 'https://play.youthdeal.net/games/upload/6943-2021-11-01.jpg'),
(143, 'https://www.yad.com/games/Giant-Rush-Online/', 'https://play.youthdeal.net/games/upload/6455-2021-11-01.jpg'),
(144, 'https://www.yad.com/games/Rocket-Punch/', 'https://play.youthdeal.net/games/upload/4340-2021-11-01.jpg'),
(145, 'https://www.yad.com/games/Epic-Defense-Clash/', 'https://play.youthdeal.net/games/upload/0636-2021-11-01.jpg'),
(146, 'https://www.yad.com/games/Tank-Invasion/', 'https://play.youthdeal.net/games/upload/9757-2021-11-01.jpg'),
(147, 'https://www.yad.com/games/Kingdom-Defense/', 'https://play.youthdeal.net/games/upload/0075-2021-11-01.jpg'),
(148, 'https://www.yad.com/games/Castle-Defense/', 'https://play.youthdeal.net/games/upload/8710-2021-11-01.jpg'),
(149, 'https://www.yad.com/games/Defense-Battle/', 'https://play.youthdeal.net/games/upload/5440-2021-11-01.jpg'),
(150, 'https://www.yad.com/games/Jack-Gunner/', 'https://play.youthdeal.net/games/upload/5395-2021-11-01.jpg'),
(151, 'https://www.yad.com/games/Machine-Gun-Squad/', 'https://play.youthdeal.net/games/upload/8556-2021-11-01.jpg'),
(152, 'https://www.yad.com/games/Red-Impostor-Vs-Crew/', 'https://play.youthdeal.net/games/upload/1340-2021-11-01.jpg'),
(153, 'https://www.yad.com/games/Draw-Joust/', 'https://play.youthdeal.net/games/upload/7945-2021-11-01.jpg'),
(154, 'https://www.yad.com/games/Idle-Lumberjack-3d/', 'https://play.youthdeal.net/games/upload/4662-2021-11-01.jpg'),
(155, 'https://www.yad.com/games/Stickman-Dash/', 'https://play.youthdeal.net/games/upload/4845-2021-11-01.jpg'),
(156, 'https://www.yad.com/games/Archero/', 'https://play.youthdeal.net/games/upload/5074-2021-11-01.jpg'),
(157, 'https://www.yad.com/games/Heroes-Inc/', 'https://play.youthdeal.net/games/upload/8181-2021-11-01.jpg'),
(158, 'https://www.yad.com/games/Agent-J/', 'https://play.youthdeal.net/games/upload/4810-2021-11-01.jpg'),
(159, 'https://www.yad.com/games/Draw-Weapons-Rush/', 'https://play.youthdeal.net/games/upload/9907-2021-11-01.jpg'),
(160, 'https://www.yad.com/games/Bullet-Rush/', 'https://play.youthdeal.net/games/upload/0225-2021-11-01.jpg'),
(161, 'https://www.yad.com/games/Halloween-Knife-Hit/', 'https://play.youthdeal.net/games/upload/0130-2021-11-01.jpg'),
(162, 'https://www.yad.com/games/One-Shot/', 'https://play.youthdeal.net/games/upload/4323-2021-11-01.jpg'),
(163, 'https://www.yad.com/games/Among-Us-Crazy-Shooter/', 'https://play.youthdeal.net/games/upload/2680-2021-11-01.jpg'),
(164, 'https://www.yad.com/games/Halloween-Pocket-Sniper-3d/', 'https://play.youthdeal.net/games/upload/7427-2021-11-01.jpg'),
(165, 'https://www.yad.com/games/Bullet-Bender-Online/', 'https://play.youthdeal.net/games/upload/2135-2021-11-01.jpg'),
(166, 'https://www.yad.com/games/Knockem-All/', 'https://play.youthdeal.net/games/upload/4340-2021-11-01.jpg'),
(167, 'https://www.yad.com/games/Crazy-Sniper-Shooter/', 'https://play.youthdeal.net/games/upload/6555-2021-11-01.jpg'),
(168, 'https://www.yad.com/games/Ace-Brawl-Battle-3d/', 'https://play.youthdeal.net/games/upload/9387-2021-11-01.jpg'),
(169, 'https://www.yad.com/games/Frozen-Sam/', 'https://play.youthdeal.net/games/upload/5932-2021-11-01.jpg'),
(170, 'https://www.yad.com/games/Halloween-Adventure/', 'https://play.youthdeal.net/games/upload/5635-2021-11-01.jpg'),
(172, 'https://html5.gamedistribution.com/1daa5d457e9e42219436f4b6ca222784/', 'https://play.youthdeal.net/games/upload/7855-2021-11-02.jpg'),
(173, 'https://html5.gamemonetize.com/ewxvolynnt7b4gdcyyehihs03qt76pvl/', 'https://play.youthdeal.net/games/upload/9304-2021-11-02.jpg'),
(174, 'https://html5.gamedistribution.com/8098ade035754d33ae443ee2a3976d29/', 'https://play.youthdeal.net/games/upload/5045-2021-11-02.jpg'),
(175, 'https://www.bestgames.com/games/Paint-Hit-Online/index.html', 'https://play.youthdeal.net/games/upload/3452-2021-11-02.jpg'),
(176, 'https://html5.gamedistribution.com/5a4aa5dcc5e948df945056f4b04b19f7/', 'https://play.youthdeal.net/games/upload/3898-2021-11-02.jpg'),
(177, 'https://www.yad.com/games/Gravity-Box/index.html', 'https://play.youthdeal.net/games/upload/8755-2021-11-02.jpg'),
(178, 'https://www.bestgames.com/games/Love-Balls-Online/index.html', 'https://play.youthdeal.net/games/upload/7616-2021-11-02.jpg'),
(179, 'https://html5.gamedistribution.com/d2314628fd9540f6b42ae1fa98a5ac9d/', 'https://play.youthdeal.net/games/upload/9469-2021-11-02.jpg'),
(180, 'https://html5.gamedistribution.com/2f28066d92e84af58278ffda7068e652/', 'https://play.youthdeal.net/games/upload/7944-2021-11-02.jpg'),
(181, 'https://html5.gamedistribution.com/143cf022a01b450c8830b37772fc64ce/', 'https://play.youthdeal.net/games/upload/9280-2021-11-02.jpg'),
(182, 'https://html5.gamedistribution.com/239dd364f45a476eb2c8d93156cf7727/', 'https://play.youthdeal.net/games/upload/5414-2021-11-02.jpg'),
(183, 'https://html5.gamedistribution.com/9292c16984694ba1925cba8ebc94aec5/', 'https://play.youthdeal.net/games/upload/9497-2021-11-02.jpg'),
(184, 'https://html5.gamedistribution.com/5a6b91ffc885438694861d90116a7a96/', 'https://play.youthdeal.net/games/upload/2972-2021-11-02.jpg'),
(185, 'https://www.yiv.com/games/Tetris-Cube/index.html', 'https://play.youthdeal.net/games/upload/9243-2021-11-02.jpg'),
(186, 'https://html5.gamedistribution.com/21c9d85a039d455890ccd67dc2555481/', 'https://play.youthdeal.net/games/upload/3372-2021-11-02.jpg'),
(187, 'https://html5.gamedistribution.com/617d17b536b0458cbcbe985f6bf9754d/', 'https://play.youthdeal.net/games/upload/5092-2021-11-02.jpg'),
(188, 'https://www.bestgames.com/games/Clone-Ball-Rush/index.html', 'https://play.youthdeal.net/games/upload/3490-2021-11-02.jpg'),
(189, 'https://html5.gamedistribution.com/a94c6436a05b496d88711fe5851830e3/', 'https://play.youthdeal.net/games/upload/4369-2021-11-02.jpg'),
(190, 'https://html5.gamedistribution.com/722176c4785042368e5b4f734cc14b9e/', 'https://play.youthdeal.net/games/upload/4589-2021-11-02.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_adventure`
--

CREATE TABLE `tbl_adventure` (
  `cid` int(11) NOT NULL,
  `adventure_link` varchar(2000) NOT NULL,
  `adventure_logo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_adventure`
--

INSERT INTO `tbl_adventure` (`cid`, `adventure_link`, `adventure_logo`) VALUES
(142, 'https://www.yiv.com/games/Wedding-Artist/index.html', 'https://play.youthdeal.net/games/upload/5605-2021-11-02.jpg'),
(143, 'https://www.yiv.com/games/Food-Educational-Games-For-Kids/index.html', 'https://play.youthdeal.net/games/upload/7359-2021-11-02.jpg'),
(144, 'https://www.babygames.com/games/Unicorn-Slime-Cooking-1/index.html', 'https://play.youthdeal.net/games/upload/8756-2021-11-02.jpg'),
(145, 'https://www.yiv.com/games/Truck-Factory-For-Kids-2/index.html', 'https://play.youthdeal.net/games/upload/8085-2021-11-02.jpg'),
(146, 'https://www.bestgames.com/games/Dingbats/index.html', 'https://play.youthdeal.net/games/upload/5260-2021-11-02.jpg'),
(147, 'https://www.yiv.com/games/Building-New-House/index.html', 'https://play.youthdeal.net/games/upload/4310-2021-11-02.jpg'),
(148, 'https://html5.gamedistribution.com/cfd23874aad14e9daa2228891622d579/', 'https://play.youthdeal.net/games/upload/0457-2021-11-02.jpg'),
(149, 'https://html5.gamedistribution.com/cb62ed5fb5214e029aa0f9c07adcdd2b/', 'https://play.youthdeal.net/games/upload/6845-2021-11-02.jpg'),
(150, 'https://html5.gamemonetize.com/l874gwz7mvbad62t9q6em46d8h5p3n5o/', 'https://play.youthdeal.net/games/upload/2757-2021-11-02.jpg'),
(151, 'https://www.yiv.com/games/Robot-Car-Emergency-Rescue/index.html', 'https://play.youthdeal.net/games/upload/4444-2021-11-02.jpg'),
(152, 'https://www.yiv.com/games/Rainbow-Ice-Cream/index.html', 'https://play.youthdeal.net/games/upload/4137-2021-11-02.jpg'),
(153, 'https://www.yiv.com/games/Spa-Day-Makeup-Artist/index.html', 'https://play.youthdeal.net/games/upload/5352-2021-11-02.jpg'),
(154, 'https://www.yiv.com/games/Little-Princess-Magical-Tale/index.html', 'https://play.youthdeal.net/games/upload/0725-2021-11-02.jpg'),
(155, 'https://www.yiv.com/games/Fairy-Pony-Caring-Adventure/index.html', 'https://play.youthdeal.net/games/upload/0142-2021-11-02.jpg'),
(156, 'https://html5.gamedistribution.com/34c219d458a64ba7b8743251ef56aa3f/', 'https://play.youthdeal.net/games/upload/9421-2021-11-02.jpg'),
(157, 'https://html5.gamemonetize.com/6tj3oef4ljmkhlhz6lggc2oe0bulobnu/', 'https://play.youthdeal.net/games/upload/4117-2021-11-02.jpg'),
(158, 'https://www.bestgames.com/games/Combine-It/index.html', 'https://play.youthdeal.net/games/upload/0008-2021-11-02.jpg'),
(159, 'https://h5.4j.com/Roll-The-Ball-2-Online/index.php?pubid=topgames', 'https://play.youthdeal.net/games/upload/2308-2021-11-02.jpg'),
(160, 'https://www.bestgames.com/games/Epic-Race-3d/index.html', 'https://play.youthdeal.net/games/upload/3566-2021-11-02.jpg'),
(161, 'https://www.yiv.com/games/Masha-And-The-Bear-In-Peace/index.html', 'https://play.youthdeal.net/games/upload/1531-2021-11-02.jpg'),
(162, 'https://html5.gamedistribution.com/25d998b0416f4a9e9e2654c099f1b5f0/', 'https://play.youthdeal.net/games/upload/4214-2021-11-02.jpg'),
(163, 'https://html5.gamedistribution.com/f18f5725594e45e9b46b080a575524ae/', 'https://play.youthdeal.net/games/upload/5707-2021-11-02.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_arcade`
--

CREATE TABLE `tbl_arcade` (
  `cid` int(11) NOT NULL,
  `arcade_link` varchar(2000) NOT NULL,
  `arcade_logo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_arcade`
--

INSERT INTO `tbl_arcade` (`cid`, `arcade_link`, `arcade_logo`) VALUES
(140, 'https://html5.gamedistribution.com/1daa5d457e9e42219436f4b6ca222784/', 'https://play.youthdeal.net/games/upload/7216-2021-11-02.jpg'),
(141, 'https://html5.gamemonetize.com/ewxvolynnt7b4gdcyyehihs03qt76pvl/', 'https://play.youthdeal.net/games/upload/7170-2021-11-02.jpg'),
(142, 'https://html5.gamedistribution.com/8098ade035754d33ae443ee2a3976d29/', 'https://play.youthdeal.net/games/upload/5929-2021-11-02.jpg'),
(143, 'https://www.bestgames.com/games/Paint-Hit-Online/index.html', 'https://play.youthdeal.net/games/upload/1029-2021-11-02.jpg'),
(144, 'https://html5.gamedistribution.com/5a4aa5dcc5e948df945056f4b04b19f7/', 'https://play.youthdeal.net/games/upload/4166-2021-11-02.jpg'),
(145, 'https://www.yad.com/games/Gravity-Box/index.html', 'https://play.youthdeal.net/games/upload/3166-2021-11-02.jpg'),
(146, 'https://www.bestgames.com/games/Love-Balls-Online/index.html', 'https://play.youthdeal.net/games/upload/3521-2021-11-02.jpg'),
(147, 'https://html5.gamedistribution.com/d2314628fd9540f6b42ae1fa98a5ac9d/', 'https://play.youthdeal.net/games/upload/3713-2021-11-02.jpg'),
(148, 'https://html5.gamedistribution.com/2f28066d92e84af58278ffda7068e652/', 'https://play.youthdeal.net/games/upload/8744-2021-11-02.jpg'),
(149, 'https://html5.gamedistribution.com/143cf022a01b450c8830b37772fc64ce/', 'https://play.youthdeal.net/games/upload/2424-2021-11-02.jpg'),
(150, 'https://html5.gamedistribution.com/239dd364f45a476eb2c8d93156cf7727/', 'https://play.youthdeal.net/games/upload/5322-2021-11-02.jpg'),
(151, 'https://html5.gamedistribution.com/9292c16984694ba1925cba8ebc94aec5/', 'https://play.youthdeal.net/games/upload/8192-2021-11-02.jpg'),
(152, 'https://html5.gamedistribution.com/5a6b91ffc885438694861d90116a7a96/', 'https://play.youthdeal.net/games/upload/4720-2021-11-02.jpg'),
(153, 'https://www.yiv.com/games/Tetris-Cube/index.html', 'https://play.youthdeal.net/games/upload/1490-2021-11-02.jpg'),
(154, 'https://html5.gamedistribution.com/21c9d85a039d455890ccd67dc2555481/', 'https://play.youthdeal.net/games/upload/8242-2021-11-02.jpg'),
(155, 'https://html5.gamedistribution.com/617d17b536b0458cbcbe985f6bf9754d/', 'https://play.youthdeal.net/games/upload/8975-2021-11-02.jpg'),
(156, 'https://www.bestgames.com/games/Clone-Ball-Rush/index.html', 'https://play.youthdeal.net/games/upload/0494-2021-11-02.jpg'),
(157, 'https://html5.gamedistribution.com/a94c6436a05b496d88711fe5851830e3/', 'https://play.youthdeal.net/games/upload/3789-2021-11-02.jpg'),
(158, 'https://html5.gamedistribution.com/722176c4785042368e5b4f734cc14b9e/', 'https://play.youthdeal.net/games/upload/1466-2021-11-02.jpg'),
(159, 'https://www.yiv.com/games/Wedding-Artist/index.html', 'https://play.youthdeal.net/games/upload/6144-2021-11-02.jpg'),
(160, 'https://www.yiv.com/games/Educational-Games-For-Kids/index.html', 'https://play.youthdeal.net/games/upload/5632-2021-11-02.jpg'),
(161, 'https://www.yiv.com/games/Picnic-With-Cat-Family/index.html', 'https://play.youthdeal.net/games/upload/7949-2021-11-02.jpg'),
(162, 'https://www.yiv.com/games/Cat-Family-Educational-Games/index.html', 'https://play.youthdeal.net/games/upload/6378-2021-11-02.jpg'),
(163, 'https://www.yiv.com/games/Cartoon-Football-Games-For-Kids/index.html', 'https://play.youthdeal.net/games/upload/6425-2021-11-02.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_puzzle`
--

CREATE TABLE `tbl_puzzle` (
  `cid` int(11) NOT NULL,
  `puzzle_link` varchar(2000) NOT NULL,
  `puzzle_logo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_puzzle`
--

INSERT INTO `tbl_puzzle` (`cid`, `puzzle_link`, `puzzle_logo`) VALUES
(140, 'https://www.yad.com/games/Puzzle-Color/', 'https://play.youthdeal.net/games/upload/5060-2021-11-02.jpg'),
(141, 'https://www.yad.com/games/Ng-Puzzle/', 'https://play.youthdeal.net/games/upload/5757-2021-11-02.jpg'),
(142, 'https://www.yad.com/games/Circle-Puzzle/', 'https://play.youthdeal.net/games/upload/5974-2021-11-02.jpg'),
(143, 'https://www.yad.com/games/Snake-Swipe-Puzzle/', 'https://play.youthdeal.net/games/upload/7160-2021-11-02.jpg'),
(144, 'https://www.yad.com/games/Emoji-Puzzle-2/', 'https://play.youthdeal.net/games/upload/6421-2021-11-02.jpg'),
(145, 'https://www.yad.com/games/Puzzle-Fuzzle-2/', 'https://play.youthdeal.net/games/upload/9285-2021-11-02.jpg'),
(146, 'https://www.yad.com/games/Square/', 'https://play.youthdeal.net/games/upload/7074-2021-11-02.jpg'),
(147, 'https://html5.gamemonetize.com/gvh7gsz106gfn26grxlo7o6tb1vg5jxm/', 'https://play.youthdeal.net/games/upload/7326-2021-11-02.jpg'),
(148, 'https://html5.gamedistribution.com/639df47033804f18bf39e113ef29f4fa/', 'https://play.youthdeal.net/games/upload/9796-2021-11-02.jpg'),
(149, 'https://www.yiv.com/games/Line-Puzzle-String-Art/index.html', 'https://play.youthdeal.net/games/upload/5570-2021-11-02.jpg'),
(150, 'https://www.bestgames.com/games/Water-Sort-Puzzle-2/index.html', 'https://play.youthdeal.net/games/upload/2165-2021-11-02.jpg'),
(151, 'https://html5.gamedistribution.com/5ab4e702d7eb409a8aee79f93a0669c8/', 'https://play.youthdeal.net/games/upload/7961-2021-11-02.jpg'),
(152, 'https://www.bestgames.com/games/Onnect-Matching-Puzzle/index.html', 'https://play.youthdeal.net/games/upload/1165-2021-11-02.jpg'),
(153, 'https://www.bestgames.com/games/Lego-Block-Puzzle/index.html', 'https://play.youthdeal.net/games/upload/1658-2021-11-02.jpg'),
(154, 'https://html5.gamemonetize.com/x5sh6olfmuz3t2h2943gu0sq97qviqig/', 'https://play.youthdeal.net/games/upload/7035-2021-11-02.jpg'),
(155, 'https://html5.gamedistribution.com/3e314ff40f40472f9aefed5b046f6dcc/', 'https://play.youthdeal.net/games/upload/6735-2021-11-02.jpg'),
(156, 'https://www.bestgames.com/games/Snake-Puzzle/index.html', 'https://play.youthdeal.net/games/upload/3607-2021-11-02.jpg'),
(157, 'https://html5.gamedistribution.com/49329bf6a79f47b2afe3a48249f97459/', 'https://play.youthdeal.net/games/upload/1492-2021-11-02.jpg'),
(158, 'https://www.bestgames.com/games/Pattern-Puzzle/index.html', 'https://play.youthdeal.net/games/upload/8439-2021-11-02.jpg'),
(159, 'https://play.famobi.com/disney-jigsaw-puzzle/A-DC230', 'https://play.youthdeal.net/games/upload/3915-2021-11-02.jpg'),
(160, 'https://html5.gamedistribution.com/e233bbfccda74f9393e7b5860bbcf9e9/', 'https://play.youthdeal.net/games/upload/5965-2021-11-02.jpg'),
(161, 'https://www.bestgames.com/games/Demolish-Castle-Puzzle/index.html', 'https://play.youthdeal.net/games/upload/1993-2021-11-02.jpg'),
(162, 'https://html5.gamedistribution.com/412548d732c440d4aca8f31139a328f8/', 'https://play.youthdeal.net/games/upload/0141-2021-11-02.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_racing`
--

CREATE TABLE `tbl_racing` (
  `cid` int(11) NOT NULL,
  `racing_link` varchar(2000) NOT NULL,
  `racing_logo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_racing`
--

INSERT INTO `tbl_racing` (`cid`, `racing_link`, `racing_logo`) VALUES
(140, 'https://html5.gamedistribution.com/7253811a3e5745b2beb97ab7c642ceff/', 'https://play.youthdeal.net/games/upload/3361-2021-11-02.jpg'),
(141, 'https://www.cargames.com/games/Turn-Over-Master/index.html', 'https://play.youthdeal.net/games/upload/8721-2021-11-02.jpg'),
(142, 'https://games.softgames.com/games/drift-race/gamesites/844/locale/en', 'https://play.youthdeal.net/games/upload/8761-2021-11-02.jpg'),
(143, 'https://html5.gamedistribution.com/1ec3d7aeb5e34ed697b0828269f469a3/', 'https://play.youthdeal.net/games/upload/1895-2021-11-02.jpg'),
(144, 'https://www.cargames.com/games/Realistic-Parking-Master/index.html', 'https://play.youthdeal.net/games/upload/1743-2021-11-02.jpg'),
(145, 'https://www.yad.com/games/Car-Rush/index.html', 'https://play.youthdeal.net/games/upload/7146-2021-11-02.jpg'),
(146, 'https://html5.distributegames.com/71bm57x78u7i2rjerysnhanpf8p2pmbw/', 'https://play.youthdeal.net/games/upload/8741-2021-11-02.jpg'),
(147, 'https://www.cargames.com/games/Real-Car-Driving-Simulator/index.html', 'https://play.youthdeal.net/games/upload/3228-2021-11-02.jpg'),
(148, 'https://html5.gamedistribution.com/76ad0846b6a74087a31d932985a6388a/', 'https://play.youthdeal.net/games/upload/1856-2021-11-02.jpg'),
(149, 'https://html5.gamedistribution.com/5b0abd4c0faa4f5eb190a9a16d5a1b4c/', 'https://play.youthdeal.net/games/upload/1648-2021-11-02.jpg'),
(150, 'https://www.bestgames.com/games/Merge-Car-Idle-Tycoon/index.html', 'https://play.youthdeal.net/games/upload/3290-2021-11-02.jpg'),
(151, 'https://html5.gamedistribution.com/12d47826be35462ba97dd21577e14288/', 'https://play.youthdeal.net/games/upload/9605-2021-11-02.jpg'),
(152, 'https://www.yiv.com/games/Gear-Madness/index.html', 'https://play.youthdeal.net/games/upload/1433-2021-11-02.jpg'),
(153, 'https://html5.gamemonetize.com/xadmbez57xew9kcphfpu4gaye4bt38t1/', 'https://play.youthdeal.net/games/upload/1474-2021-11-02.jpg'),
(154, 'https://html5.gamedistribution.com/e25b9026f7a5405ab484f06516f750b2/', 'https://play.youthdeal.net/games/upload/0211-2021-11-02.jpg'),
(155, 'https://html5.gamedistribution.com/0140599dec0645229f039926e9ae168c/', 'https://play.youthdeal.net/games/upload/5352-2021-11-02.jpg'),
(156, 'https://www.yiv.com/games/Hill-Climb-Racing/index.html', 'https://play.youthdeal.net/games/upload/4372-2021-11-02.jpg'),
(157, 'https://www.cargames.com/games/Traffic-Racer-King/index.html', 'https://play.youthdeal.net/games/upload/4261-2021-11-02.jpg'),
(158, 'https://www.bestgames.com/games/Wacky-Run/index.html', 'https://play.youthdeal.net/games/upload/4669-2021-11-02.jpg'),
(159, 'https://html5.gamedistribution.com/40c5051acae84fb98d30a0bf14119cb5/', 'https://play.youthdeal.net/games/upload/0348-2021-11-02.jpg'),
(160, 'https://www.yad.com/games/Hurdles/index.html', 'https://play.youthdeal.net/games/upload/4094-2021-11-02.jpg'),
(161, 'https://www.bestgames.com/games/Gear-Race-3d/index.html', 'https://play.youthdeal.net/games/upload/8859-2021-11-02.jpg'),
(162, 'https://www.bestgames.com/games/Body-Race/index.html', 'https://play.youthdeal.net/games/upload/1272-2021-11-02.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sports`
--

CREATE TABLE `tbl_sports` (
  `cid` int(11) NOT NULL,
  `sports_link` varchar(2000) NOT NULL,
  `sports_logo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_sports`
--

INSERT INTO `tbl_sports` (`cid`, `sports_link`, `sports_logo`) VALUES
(140, 'https://www.babyhazelgames.com/html5/bhsportsday/', 'https://play.youthdeal.net/games/upload/9126-2021-11-02.jpg'),
(141, 'https://html5.gamedistribution.com/828a7097d9a84bae9bc1b248909185e0/', 'https://play.youthdeal.net/games/upload/4267-2021-11-02.jpg'),
(142, 'https://html5.gamedistribution.com/8415a28346d447c6be0cdc4180fe1ed2/', 'https://play.youthdeal.net/games/upload/9245-2021-11-02.jpg'),
(143, 'https://html5.gamedistribution.com/3e68a721f20b423b92e0456ae38d676b/', 'https://play.youthdeal.net/games/upload/7528-2021-11-02.jpg'),
(144, 'https://html5.gamedistribution.com/53aea3f5882b43b9a1939002dcc07ba5/', 'https://play.youthdeal.net/games/upload/2892-2021-11-02.jpg'),
(145, 'https://www.yad.com/games/Rolling-The-Ball/index.html', 'https://play.youthdeal.net/games/upload/7463-2021-11-02.jpg'),
(146, 'https://html5.gamedistribution.com/080f5ad406b642adb0853aaac9b20ad6/', 'https://play.youthdeal.net/games/upload/1837-2021-11-02.jpg'),
(147, 'https://html5.gamedistribution.com/37bed47866eb4730a2522c524f4edb45/', 'https://play.youthdeal.net/games/upload/6056-2021-11-02.jpg'),
(148, 'https://www.bestgames.com/games/Fast-Driver-3d/index.html', 'https://play.youthdeal.net/games/upload/6931-2021-11-02.jpg'),
(149, 'https://files.twoplayergames.org/files/games/other/Sports_Minibattles/index.html', 'https://play.youthdeal.net/games/upload/2243-2021-11-02.jpg'),
(150, 'https://www.yiv.com/games/Robot-Car-Emergency-Rescue-2/index.html', 'https://play.youthdeal.net/games/upload/8630-2021-11-02.jpg'),
(151, 'https://www.bestgames.com/games/Happy-Hockey/index.html', 'https://play.youthdeal.net/games/upload/5321-2021-11-02.jpg'),
(152, 'https://html5.gamedistribution.com/fb21e6d781194458862534727960fba6/', 'https://play.youthdeal.net/games/upload/8883-2021-11-02.jpg'),
(153, 'https://www.yiv.com/games/Monster-Truck-Repairing/index.html', 'https://play.youthdeal.net/games/upload/9727-2021-11-02.jpg'),
(154, 'https://www.cargames.com/games/Car-Parking-Pro/index.html', 'https://play.youthdeal.net/games/upload/5174-2021-11-02.jpg'),
(155, 'https://www.bestgames.com/games/Run-Royale-3d/index.html', 'https://play.youthdeal.net/games/upload/7985-2021-11-02.jpg'),
(156, 'https://www.yad.com/games/Fall-Guys-Knockout/index.html', 'https://play.youthdeal.net/games/upload/9239-2021-11-02.jpg'),
(157, 'https://html5.gamemonetize.com/8h5t2mokvehtxkby2boi81vwx0yn4xwd/', 'https://play.youthdeal.net/games/upload/6001-2021-11-02.jpg'),
(158, 'https://www.yiv.com/games/Sweet-Baby-Girl-Cleanup-Messy-School/index.html', 'https://play.youthdeal.net/games/upload/4380-2021-11-02.jpg'),
(159, 'https://cdn.htmlgames.com/BlockTown/index.html', 'https://play.youthdeal.net/games/upload/1594-2021-11-02.jpg'),
(160, 'https://www.yiv.com/games/Cat-Hair-Salon/index.html', 'https://play.youthdeal.net/games/upload/4335-2021-11-02.jpg'),
(161, 'https://html5.gamedistribution.com/8f02fb03334e43b88f9cb21fd1148912/', 'https://play.youthdeal.net/games/upload/0787-2021-11-02.jpg'),
(162, 'https://www.bestgames.com/games/Pop-It-Bubble-Game/index.html', 'https://play.youthdeal.net/games/upload/3462-2021-11-02.jpg'),
(163, 'https://www.yad.com/games/Join-Pusher-3d/index.html', 'https://play.youthdeal.net/games/upload/7187-2021-11-02.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` int(11) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` text NOT NULL,
  `email` varchar(100) NOT NULL,
  `user_role` enum('100','101','102') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `username`, `password`, `email`, `user_role`) VALUES
(1, 'admin', 'd82494f05d6917ba02f7aaa29689ccb444bb73f20380876cb05d1f37537b7892', 'gurujibd.official@gmail.com', '100');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_zombie`
--

CREATE TABLE `tbl_zombie` (
  `cid` int(11) NOT NULL,
  `zombie_link` varchar(2000) NOT NULL,
  `zombie_logo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_zombie`
--

INSERT INTO `tbl_zombie` (`cid`, `zombie_link`, `zombie_logo`) VALUES
(142, 'https://html5.gamemonetize.com/iz9n0kx3zqfl4mo657zpb5y7v7qfbxij/', 'https://play.youthdeal.net/games/upload/8270-2021-11-02.jpg'),
(143, 'https://www.gamessumo.com/games/plants', 'https://play.youthdeal.net/games/upload/9384-2021-11-02.jpg'),
(144, 'https://www.yad.com/games/Save-The-Girl/index.html', 'https://play.youthdeal.net/games/upload/8353-2021-11-02.jpg'),
(145, 'https://www.yad.com/games/Grand-Commander/index.html', 'https://play.youthdeal.net/games/upload/7273-2021-11-02.jpg'),
(146, 'https://www.bestgames.com/games/Zombie-Royale/index.html', 'https://play.youthdeal.net/games/upload/7830-2021-11-02.jpg'),
(147, 'https://h5.4j.com/Zombie-Shooter/index.php', 'https://play.youthdeal.net/games/upload/5616-2021-11-02.jpg'),
(148, 'https://html5.gamedistribution.com/123c219b8bf0425dbdf14d9663c5029e/', 'https://play.youthdeal.net/games/upload/2109-2021-11-02.jpg'),
(149, 'https://html5.gamedistribution.com/1597d5db4820455998662542c42f7a81/', 'https://play.youthdeal.net/games/upload/4375-2021-11-02.jpg'),
(150, 'https://www.yiv.com/games/Dead-City/index.html', 'https://play.youthdeal.net/games/upload/0762-2021-11-02.jpg'),
(151, 'https://www.yiv.com/games/Dead-Land-Adventure/index.html', 'https://play.youthdeal.net/games/upload/2972-2021-11-02.jpg'),
(152, 'https://www.yiv.com/games/Toto-Adventure/index.html', 'https://play.youthdeal.net/games/upload/4528-2021-11-02.jpg'),
(153, 'https://www.babygames.com/games/Baby-Taylor-Halloween-Adventure/index.html', 'https://play.youthdeal.net/games/upload/0747-2021-11-02.jpg'),
(154, 'https://html5.gamedistribution.com/9ce4634b6e1d4d62b27cdd7a5860fcdf/', 'https://play.youthdeal.net/games/upload/7487-2021-11-02.jpg'),
(155, 'https://html5.gamedistribution.com/8008ab44b4924597bb8f6de6d27cf363/', 'https://play.youthdeal.net/games/upload/5412-2021-11-02.jpg'),
(156, 'https://www.yiv.com/games/Halloween-Pencil/index.html', 'https://play.youthdeal.net/games/upload/0799-2021-11-02.jpg'),
(157, 'https://html5.gamedistribution.com/5fe4d406eee64654b765c9248c88f046/', 'https://play.youthdeal.net/games/upload/0654-2021-11-02.jpg'),
(158, 'https://html5.gamedistribution.com/4cfc17c3192c4c6694bc8228cf53d15a/', 'https://play.youthdeal.net/games/upload/6401-2021-11-02.jpg'),
(159, 'https://www.bestgames.com/games/Zombie-Royale/index.html', 'https://play.youthdeal.net/games/upload/8722-2021-11-02.jpg'),
(160, 'https://html5.gamemonetize.com/remxzd9vohvptab7umue33gtiyh2210t/', 'https://play.youthdeal.net/games/upload/0780-2021-11-02.jpg'),
(161, 'https://html5.gamedistribution.com/e7c3bc4ebe9e4241a82692cad09b379a/', 'https://play.youthdeal.net/games/upload/7566-2021-11-02.jpg'),
(162, 'https://html5.gamemonetize.com/pxmydjw19o6ol8su1uyfv7ub4okhdmgc/', 'https://play.youthdeal.net/games/upload/4537-2021-11-02.jpg'),
(163, 'https://html5.gamedistribution.com/d23ef0b52dff4139877d090b333177fe/', 'https://play.youthdeal.net/games/upload/9734-2021-11-02.jpg'),
(164, 'https://html5.gamedistribution.com/67e4d5b2bb3e46f585165f9d0b060f04/', 'https://play.youthdeal.net/games/upload/7774-2021-11-02.jpg'),
(165, 'https://html5.gamemonetize.com/p1kzu5rt2ccr02gzr1sf5sarx8if93er/', 'https://play.youthdeal.net/games/upload/0687-2021-11-02.jpg'),
(166, 'https://html5.gamemonetize.com/bdgbp5mtnic2fomnsp5zg7hcl2vm15ad/', 'https://play.youthdeal.net/games/upload/5426-2021-11-02.jpg'),
(167, 'https://html5.gamedistribution.com/c87a32902f7f486bbd639514cfa5cb58/', 'https://play.youthdeal.net/games/upload/5917-2021-11-02.jpg'),
(168, 'https://html5.gamemonetize.com/o2f1x5xxg5d8h7m94aa3pjvsw8l4y3am/', 'https://play.youthdeal.net/games/upload/8999-2021-11-02.jpg'),
(169, 'https://html5.gamedistribution.com/ff3040ca58e24188bd91baa6a2904d00/', 'https://play.youthdeal.net/games/upload/1950-2021-11-02.jpg'),
(170, 'https://html5.gamedistribution.com/327959f8bd9a4d1e84f29852aef7f6ce/', 'https://play.youthdeal.net/games/upload/2583-2021-11-02.jpg'),
(171, 'https://html5.gamedistribution.com/8a0b93c787bb47f49a7a9d0d9d6643d1/', 'https://play.youthdeal.net/games/upload/1196-2021-11-02.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_action`
--
ALTER TABLE `tbl_action`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `tbl_adventure`
--
ALTER TABLE `tbl_adventure`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `tbl_arcade`
--
ALTER TABLE `tbl_arcade`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `tbl_puzzle`
--
ALTER TABLE `tbl_puzzle`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `tbl_racing`
--
ALTER TABLE `tbl_racing`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `tbl_sports`
--
ALTER TABLE `tbl_sports`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_zombie`
--
ALTER TABLE `tbl_zombie`
  ADD PRIMARY KEY (`cid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_action`
--
ALTER TABLE `tbl_action`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=202;

--
-- AUTO_INCREMENT for table `tbl_adventure`
--
ALTER TABLE `tbl_adventure`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=165;

--
-- AUTO_INCREMENT for table `tbl_arcade`
--
ALTER TABLE `tbl_arcade`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=164;

--
-- AUTO_INCREMENT for table `tbl_puzzle`
--
ALTER TABLE `tbl_puzzle`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=163;

--
-- AUTO_INCREMENT for table `tbl_racing`
--
ALTER TABLE `tbl_racing`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=163;

--
-- AUTO_INCREMENT for table `tbl_sports`
--
ALTER TABLE `tbl_sports`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=164;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_zombie`
--
ALTER TABLE `tbl_zombie`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=172;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
