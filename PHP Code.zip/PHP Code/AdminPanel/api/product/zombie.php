<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

//include database and object files
include_once '../config/database.php';
include_once '../objects/zombie.php';

//instantiate database and product object
$database = new Databse();
$db = $database->getConnection();

//initialize object
$bn_data = new Zombie($db);

//query products
$stmt = $bn_data->readAll();
$num = $stmt->rowCount();

//check if more than 0 record is found
if($num>0){
    
    $data = "";
    $x = 1;
    
    //retreive table contents
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        //extract row
        extract($row);
        
        $data .= '{';
		$data .= '"cid":"' . $cid . '", ';
        $data .= '"zombie_link":"' . $zombie_link . '", ';
        $data .= '"zombie_logo":"' . $zombie_logo . '"';
        $data .= '}';
        
        $data .= $x<$num ? ',' : '';
        $x++;
    }
    //json format output
    echo "[{$data}]";
}
else{
    echo '[{}]';
}

?>