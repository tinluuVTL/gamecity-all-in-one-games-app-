<?php
class Zombie{
    
    //database connection and table name
    private $conn;
    private $table_name = "tbl_zombie";
    
    //object properties
	public $cid;
    public $zombie_link;
    public $zombie_logo;
    
    //constructor with $db as database connection
    public function __construct($db){
        $this->conn = $db;
    }
    
    //read products
    function readAll(){
        
        //select all query
        $query = "SELECT c.cid, p.zombie_link, p.zombie_logo
        FROM 
        " . $this->table_name . " p
        LEFT JOIN 
        tbl_zombie c 
        ON p.cid = c.cid
        ORDER BY 
        p.cid DESC";
        
        //prepare query statement
        $stmt = $this->conn->prepare($query);
        
        //execute query
        $stmt->execute();
        return $stmt;
    }
}

?>