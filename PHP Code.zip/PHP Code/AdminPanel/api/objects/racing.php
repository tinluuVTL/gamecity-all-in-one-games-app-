<?php
class Racing{
    
    //database connection and table name
    private $conn;
    private $table_name = "tbl_racing";
    
    //object properties
	public $cid;
    public $racing_link;
    public $racing_logo;
    
    //constructor with $db as database connection
    public function __construct($db){
        $this->conn = $db;
    }
    
    //read products
    function readAll(){
        
        //select all query
        $query = "SELECT c.cid, p.racing_link, p.racing_logo
        FROM 
        " . $this->table_name . " p
        LEFT JOIN 
        tbl_racing c 
        ON p.cid = c.cid
        ORDER BY 
        p.cid DESC";
        
        //prepare query statement
        $stmt = $this->conn->prepare($query);
        
        //execute query
        $stmt->execute();
        return $stmt;
    }
}

?>