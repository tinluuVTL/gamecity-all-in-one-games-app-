<?php
class Adventure{
    
    //database connection and table name
    private $conn;
    private $table_name = "tbl_adventure";
    
    //object properties
	public $cid;
    public $adventure_link;
    public $adventure_logo;
    
    //constructor with $db as database connection
    public function __construct($db){
        $this->conn = $db;
    }
    
    //read products
    function readAll(){
        
        //select all query
        $query = "SELECT c.cid, p.adventure_link, p.adventure_logo
        FROM 
        " . $this->table_name . " p
        LEFT JOIN 
        tbl_adventure c 
        ON p.cid = c.cid
        ORDER BY 
        p.cid DESC";
        
        //prepare query statement
        $stmt = $this->conn->prepare($query);
        
        //execute query
        $stmt->execute();
        return $stmt;
    }
}

?>