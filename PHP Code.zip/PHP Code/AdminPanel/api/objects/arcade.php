<?php
class Arcade{
    
    //database connection and table name
    private $conn;
    private $table_name = "tbl_arcade";
    
    //object properties
	public $cid;
    public $arcade_link;
    public $arcade_logo;
    
    //constructor with $db as database connection
    public function __construct($db){
        $this->conn = $db;
    }
    
    //read products
    function readAll(){
        
        //select all query
        $query = "SELECT c.cid, p.arcade_link, p.arcade_logo
        FROM 
        " . $this->table_name . " p
        LEFT JOIN 
        tbl_arcade c 
        ON p.cid = c.cid
        ORDER BY 
        p.cid DESC";
        
        //prepare query statement
        $stmt = $this->conn->prepare($query);
        
        //execute query
        $stmt->execute();
        return $stmt;
    }
}

?>