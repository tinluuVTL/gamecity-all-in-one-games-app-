<?php include('session.php'); ?>
<?php include('public/menubar.php'); ?>
<?php include('public/edit-action-form.php'); ?>
<?php include('public/footer.php'); ?>