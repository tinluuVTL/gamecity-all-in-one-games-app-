<?php include('session.php'); ?>
<?php include('public/menubar.php'); ?>
<?php include('public/edit-puzzle-form.php'); ?>
<?php include('public/footer.php'); ?>