<?php include_once('functions.php'); ?>

<?php
 //custom function for getting website link and dirname
 function get_abs_path() {
    $url = 'http';
    if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
        $url = 'https';
    }
    $url = "$url://$_SERVER[HTTP_HOST]";
    $basename = dirname($_SERVER['PHP_SELF']) . '/';
    return $url . $basename;    
}

    if (isset($_GET['id'])) {
        $ID = $_GET['id'];
    } else {
        $ID = "";
    }

    // create array variable to store category data
    $category_data = array();

    $sql_query = "SELECT puzzle_logo
                    FROM tbl_puzzle
                    WHERE cid = ?";

    $stmt_category = $connect->stmt_init();
    if ($stmt_category->prepare($sql_query)) {
        // Bind your variables to replace the ?s
        $stmt_category->bind_param('s', $ID);
        // Execute query
        $stmt_category->execute();
        // store result
        $stmt_category->store_result();
        $stmt_category->bind_result($previous_category_image);
        $stmt_category->fetch();
        $stmt_category->close();
    }


    if (isset($_POST['btnEdit'])) {
        $puzzle_link = $_POST['puzzle_link'];

        // get image info
        $menu_image = $_FILES['puzzle_logo']['name'];
        $image_error = $_FILES['puzzle_logo']['error'];
        $image_type = $_FILES['puzzle_logo']['type'];

        // create array variable to handle error
        $error = array();

        if (empty($puzzle_link)) {
            $error['puzzle_link'] = " <span class='label label-danger'>Must Insert!</span>";
        }

        // common image file extensions
        $allowedExts = array("gif", "jpeg", "jpg", "png");

        // get image file extension
        error_reporting(E_ERROR | E_PARSE);
        $extension = end(explode(".", $_FILES["puzzle_logo"]["name"]));

        if (!empty($menu_image)) {
            if (!(($image_type == "image/gif") ||
                    ($image_type == "image/jpeg") ||
                    ($image_type == "image/jpg") ||
                    ($image_type == "image/x-png") ||
                    ($image_type == "image/png") ||
                    ($image_type == "image/pjpeg")) &&
                !(in_array($extension, $allowedExts))
            ) {

                $error['puzzle_logo'] = " <span class='label label-danger'>Image type must jpg, jpeg, gif, or png!</span>";
            }
        }

        if (!empty($puzzle_link) && empty($error['puzzle_logo'])) {

            if (!empty($menu_image)) {

                // create random image file name
                $string = '0123456789';
                $file = preg_replace("/\s+/", "_", $_FILES['puzzle_logo']['name']);
                $function = new functions;
                $puzzle_logo = $function-> $extension;

                // delete previous image
                $delete = unlink('upload/' . "$previous_category_image");

                // upload new image
                
                $upload = move_uploaded_file($_FILES['puzzle_logo']['tmp_name'], 'upload/' . $menu_image);

                $sql_query = "UPDATE tbl_puzzle
                                SET puzzle_link = ?, puzzle_logo = ?
                                WHERE cid = ?";

                $upload_image = get_abs_path() . 'upload/'.$menu_image . $puzzle_logo;
                $stmt = $connect->stmt_init();
                if ($stmt->prepare($sql_query)) {
                    // Bind your variables to replace the ?s
                    $stmt->bind_param('sss',
                        $puzzle_link,
                        $upload_image,
                        $ID);
                    // Execute query
                    $stmt->execute();
                    // store result
                    $update_result = $stmt->store_result();
                    $stmt->close();
                }
            } else {

                $sql_query = "UPDATE tbl_puzzle
                                SET puzzle_link = ?
                                WHERE cid = ?";

                $stmt = $connect->stmt_init();
                if ($stmt->prepare($sql_query)) {
                    // Bind your variables to replace the ?s
                    $stmt->bind_param('ss',
                        $puzzle_link,
                        $ID);
                    // Execute query
                    $stmt->execute();
                    // store result
                    $update_result = $stmt->store_result();
                    $stmt->close();
                }
            }

            // check update result
            if ($update_result) {
                $error['update_puzzle'] = "<div class='card-panel teal lighten-2'>
                                                        <span class='white-text text-darken-2'>
                                                            Website Successfully Updated...
                                                        </span>
                                                    </div>";
            } else {
                $error['update_puzzle'] = "<div class='card-panel red darken-1'>
                                                        <span class='white-text text-darken-2'>
                                                            Update Failed
                                                        </span>
                                                    </div>";
            }
        }

    }

    // create array variable to store previous data
    $data = array();

    $sql_query = "SELECT *
                    FROM tbl_puzzle
                    WHERE cid = ?";

    $stmt = $connect->stmt_init();
    if ($stmt->prepare($sql_query)) {
        // Bind your variables to replace the ?s
        $stmt->bind_param('s', $ID);
        // Execute query
        $stmt->execute();
        // store result
        $stmt->store_result();
        $stmt->bind_result($data['cid'],
            $data['puzzle_link'],
            $data['puzzle_logo']
        );
        $stmt->fetch();
        $stmt->close();
    }

    if (isset($_POST['btnCancel'])) {
        header("location: puzzle.php");
    }

?>

    <!-- START CONTENT -->
    <section id="content">

        <!--breadcrumbs start-->
        <div id="breadcrumbs-wrapper" class=" grey lighten-3">
            <div class="container">
                <div class="row">
                    <div class="col s12 m12 l12">
                        <h5 class="breadcrumbs-title">Edit puzzle</h5>
                        <ol class="breadcrumb">
                            <li><a href="dashboard.php">Dashboard</a></li>
                            <li><a href="puzzle.php">Manage puzzle</a></li>
                            <li><a class="active">Edit puzzle</a></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <!--breadcrumbs end-->

        <!--start container-->
        <div class="container">
            <div class="section">
                <div class="row">
                    <div class="col s12 m12 l12">
                        <div class="card-panel">
                            <div class="row">
                                <form method="post" class="col s12" enctype="multipart/form-data">
                                    <div class="row">
                                        <div class="input-field col s12">
                                            <?php echo isset($error['update_puzzle']) ? $error['update_puzzle'] : ''; ?>

                                            <div class="row">
                                                <div class="input-field col s12">
                                                    <input type="url" name="puzzle_link" id="puzzle_link"
                                                           value="<?php echo $data['puzzle_link']; ?>" required/>
                                                    <label for="puzzle_link">Website Link:</label><?php echo isset($error['puzzle_link']) ? $error['puzzle_link'] : ''; ?>
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="input-field col s12 m12 l5">
                                                    <input type="file" name="puzzle_logo" id="puzzle_logo"
                                                           class="dropify-image" data-max-file-size="1M"
                                                           data-allowed-file-extensions="jpg png gif"
                                                           data-default-file="<?php echo $data['puzzle_logo']; ?>"
                                                           data-show-remove="false"/>
                                                    <div class="div-error"><?php echo isset($error['puzzle_logo']) ? $error['puzzle_logo'] : ''; ?></div>
                                                </div>
                                            </div>

                                            <button class="btn cyan waves-effect waves-light right"
                                                    type="submit" name="btnEdit">Update
                                                <i class="mdi-content-send right"></i>
                                            </button>

                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
