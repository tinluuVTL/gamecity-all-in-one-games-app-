<?php

  //Total bangla website count
  $sql_bd = "SELECT COUNT(*) as num FROM tbl_action";
  $total_action = mysqli_query($connect, $sql_bd);
  $total_action = mysqli_fetch_array($total_action);
  $total_action = $total_action['num'];

  //Total english website count
  $sql_en = "SELECT COUNT(*) as num FROM tbl_puzzle";
  $total_puzzle = mysqli_query($connect, $sql_en);
  $total_puzzle = mysqli_fetch_array($total_puzzle);
  $total_puzzle = $total_puzzle['num'];
  
    //Total english website count
  $sql_en = "SELECT COUNT(*) as num FROM tbl_arcade";
  $total_arcade = mysqli_query($connect, $sql_en);
  $total_arcade = mysqli_fetch_array($total_arcade);
  $total_arcade = $total_arcade['num'];
  
  //Total hindi website count
  $sql_in = "SELECT COUNT(*) as num FROM tbl_adventure";
  $total_adventure = mysqli_query($connect, $sql_in);
  $total_adventure = mysqli_fetch_array($total_adventure);
  $total_adventure = $total_adventure['num'];

  //Total hindi website count
  $sql_in = "SELECT COUNT(*) as num FROM tbl_sports";
  $total_sports = mysqli_query($connect, $sql_in);
  $total_sports = mysqli_fetch_array($total_sports);
  $total_sports = $total_sports['num'];
  
  //Total hindi website count
  $sql_in = "SELECT COUNT(*) as num FROM tbl_racing";
  $total_racing = mysqli_query($connect, $sql_in);
  $total_racing = mysqli_fetch_array($total_racing);
  $total_racing = $total_racing['num'];
  
  //Total hindi website count
  $sql_in = "SELECT COUNT(*) as num FROM tbl_zombie";
  $total_zombie = mysqli_query($connect, $sql_in);
  $total_zombie = mysqli_fetch_array($total_zombie);
  $total_zombie = $total_zombie['num'];
  
?>
        <!--breadcrumbs start-->
        <div id="breadcrumbs-wrapper" class=" grey lighten-3">
          <div class="container">
            <div class="row">
              <div class="col s12 m12 l12">
                <h5 class="breadcrumbs-title">Dashboard</h5>
                <ol class="breadcrumb">
                  <li><a href="dashboard.php">Dashboard</a>
                  </li>
                  <li><a href="#" class="active">Home</a>
                </ol>
              </div>
            </div>
          </div>
        </div>
        <!--breadcrumbs end-->

        <!--start container-->
        <div class="container">
            <div class="section">

                        <!--card stats start-->
            <div id="card-stats" class="seaction">
              <div class="row">
                            <div class="col s12 m6 l3">
                            <a href="action.php">
                                <div class="card">
                                    <div class="card-content grey white-text">
                                    <br>
                                        <p class="card-stats-title"><i class="fa fa-globe" aria-hidden="true"></i></i> Action Games</p>
                                        <h4 class="card-stats-number"><?php echo $total_action;?></h4>
                                        <p class="card-stats-compare"><span class="blue-grey-text text-lighten-5">Total Games</span>
                                        </p>
                                    <br>
                                    </div>
                                </div>
                            </a>
                            </div>

                            <div class="col s12 m6 l3">
                            <a href="puzzle.php">
                                <div class="card">
                                    <div class="card-content grey white-text">
                                    <br>
                                        <p class="card-stats-title"><i class="fa fa-globe" aria-hidden="true"></i> Puzzle Games</p>
                                        <h4 class="card-stats-number"><?php echo $total_puzzle;?></h4>
                                        <p class="card-stats-compare"><span class="blue-grey-text text-lighten-5">Total Games</span>
                                        </p>
                                    <br>
                                    </div>
                                </div>
                            </a>
                            </div>
                            
                            <div class="col s12 m6 l3">
                            <a href="arcade.php">
                                <div class="card">
                                    <div class="card-content grey white-text">
                                    <br>
                                        <p class="card-stats-title"><i class="fa fa-globe" aria-hidden="true"></i> Arcade Games</p>
                                        <h4 class="card-stats-number"><?php echo $total_arcade;?></h4>
                                        <p class="card-stats-compare"><span class="blue-grey-text text-lighten-5">Total Games</span>
                                        </p>
                                    <br>
                                    </div>
                                </div>
                            </a>
                            </div>
                            
                             <div class="col s12 m6 l3">
                            <a href="adventure.php">
                                <div class="card">
                                    <div class="card-content grey white-text">
                                    <br>
                                        <p class="card-stats-title"><i class="fa fa-globe" aria-hidden="true"></i></i> Adventure Games</p>
                                        <h4 class="card-stats-number"><?php echo $total_adventure;?></h4>
                                        <p class="card-stats-compare"><span class="blue-grey-text text-lighten-5">Total Games</span>
                                        </p>
                                    <br>
                                    </div>
                                </div>
                            </a>
                            </div>
                            
                            <div class="col s12 m6 l3">
                            <a href="sports.php">
                                <div class="card">
                                    <div class="card-content grey white-text">
                                    <br>
                                        <p class="card-stats-title"><i class="fa fa-globe" aria-hidden="true"></i></i> Sports Games</p>
                                        <h4 class="card-stats-number"><?php echo $total_sports;?></h4>
                                        <p class="card-stats-compare"><span class="blue-grey-text text-lighten-5">Total Games</span>
                                        </p>
                                    <br>
                                    </div>
                                </div>
                            </a>
                            </div>
                            
                            <div class="col s12 m6 l3">
                            <a href="racing.php">
                                <div class="card">
                                    <div class="card-content grey white-text">
                                    <br>
                                        <p class="card-stats-title"><i class="fa fa-globe" aria-hidden="true"></i></i> Racing Games</p>
                                        <h4 class="card-stats-number"><?php echo $total_racing;?></h4>
                                        <p class="card-stats-compare"><span class="blue-grey-text text-lighten-5">Total Games</span>
                                        </p>
                                    <br>
                                    </div>
                                </div>
                            </a>
                            </div>
                            
                            <div class="col s12 m6 l3">
                            <a href="zombie.php">
                                <div class="card">
                                    <div class="card-content grey white-text">
                                    <br>
                                        <p class="card-stats-title"><i class="fa fa-globe" aria-hidden="true"></i></i> Zombie Games</p>
                                        <h4 class="card-stats-number"><?php echo $total_zombie;?></h4>
                                        <p class="card-stats-compare"><span class="blue-grey-text text-lighten-5">Total Games</span>
                                        </p>
                                    <br>
                                    </div>
                                </div>
                            </a>
                            </div>

                            <div class="col s12 m6 l3">
                            <a href="members.php">
                                <div class="card">
                                    <div class="card-content grey white-text">
                                    <br>
                                        <p class="card-stats-title"><i class="mdi-hardware-desktop-mac"></i> Administrator</p>
                                        <h4 class="card-stats-number"><i class="fa fa-user" aria-hidden="true"></i></h4>
                                        <p class="card-stats-compare"><span class="blue-grey-text text-lighten-5">My Staff</span>
                                        </p>
                                    <br>
                                    </div>
                                </div>
                            </a>
                            </div>
                        </div>
            </div>
            <!--card stats end-->
    </div>
</div> 
