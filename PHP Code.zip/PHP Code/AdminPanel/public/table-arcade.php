<?php

	$sql_query = "SELECT * FROM tbl_arcade ORDER BY cid DESC";
	$result = mysqli_query($connect, $sql_query);

 ?>

	<!-- START CONTENT -->
    <section id="content">

        <!--breadcrumbs start-->
        <div id="breadcrumbs-wrapper" class=" grey lighten-3">
          	<div class="container">
            	<div class="row">
              		<div class="col s12 m12 l12">
               			<h5 class="breadcrumbs-title">Manage Arcade</h5>
		                <ol class="breadcrumb">
		                  <li><a href="dashboard.php">Dashboard</a></li>
		                  <li><a class="active">Manage Arcade</a></li>
		                </ol>
              		</div>
            	</div>
          	</div>
        </div>
        <!--breadcrumbs end-->

        <!--start container-->
        <div class="container">
          	<div class="section">
				<div class="row">
		        	<div class="col s12 m12 l12">
		        	<div align="right"><a href="add-arcade.php" class="btn waves-effect waves-light indigo">Add Arcade</a></div>
		        		
		        		<div class="card-panel">



		<table id="table_category" class="responsive-table display" cellspacing="0">		         
			<thead>
				<tr>
					<th class="hide-column">ID</th>
					<th width="10%">No.</th>
					<th width="40%">Link</th>
					<th width="35%">Logo</th>
					<th width="15%">Action</th>
				</tr>
			</thead>   

			<tbody>
				<?php 
					$i = 1;
					while($data = mysqli_fetch_array($result)) {
				?>

	            <tr>
	            	<td class="hide-column"><?php echo $data['cid'];?></td>
	            	<td>
	            		<?php
		                    echo $i;
		                    $i++;
		                ?>
	            	</td>
	                <td><?php echo $data['arcade_link'];?></td>
	            	<td><img src="<?php echo $data['arcade_logo'];?>" height="54px" width="54px"/></td> 
	                <td>
						<a href="edit-arcade.php?id=<?php echo $data['cid'];?>" >
	                      <i class="mdi-editor-mode-edit"></i>
	                    </a>

	                    <a href="delete-arcade.php?id=<?php echo $data['cid'];?>" onclick="return confirm('Are you sure want to delete this website?')" >
	                      <i class="mdi-action-delete"></i>
	                    </a>

					</td>
	            </tr>

	            <?php } ?>
			</tbody>

		</table>
				    </div>
						</div>
					</div>
				</div>
			</div>
		</div>

</section>
