<?php include_once('functions.php'); ?>

<?php
 //custom function for getting website link and dirname
 function get_abs_path() {
    $url = 'http';
    if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
        $url = 'https';
    }
    $url = "$url://$_SERVER[HTTP_HOST]";
    $basename = dirname($_SERVER['PHP_SELF']) . '/';
    return $url . $basename;    
}

    if (isset($_GET['id'])) {
        $ID = $_GET['id'];
    } else {
        $ID = "";
    }

    // create array variable to store category data
    $category_data = array();

    $sql_query = "SELECT action_logo
                    FROM tbl_action
                    WHERE cid = ?";

    $stmt_category = $connect->stmt_init();
    if ($stmt_category->prepare($sql_query)) {
        // Bind your variables to replace the ?s
        $stmt_category->bind_param('s', $ID);
        // Execute query
        $stmt_category->execute();
        // store result
        $stmt_category->store_result();
        $stmt_category->bind_result($previous_category_image);
        $stmt_category->fetch();
        $stmt_category->close();
    }


    if (isset($_POST['btnEdit'])) {
        $action_link = $_POST['action_link'];

        // get image info
        $menu_image = $_FILES['action_logo']['name'];
        $image_error = $_FILES['action_logo']['error'];
        $image_type = $_FILES['action_logo']['type'];

        // create array variable to handle error
        $error = array();

        if (empty($action_link)) {
            $error['action_link'] = " <span class='label label-danger'>Must Insert!</span>";
        }

        // common image file extensions
        $allowedExts = array("gif", "jpeg", "jpg", "png");

        // get image file extension
        error_reporting(E_ERROR | E_PARSE);
        $extension = end(explode(".", $_FILES["action_logo"]["name"]));

        if (!empty($menu_image)) {
            if (!(($image_type == "image/gif") ||
                    ($image_type == "image/jpeg") ||
                    ($image_type == "image/jpg") ||
                    ($image_type == "image/x-png") ||
                    ($image_type == "image/png") ||
                    ($image_type == "image/pjpeg")) &&
                !(in_array($extension, $allowedExts))
            ) {

                $error['action_logo'] = " <span class='label label-danger'>Image type must jpg, jpeg, gif, or png!</span>";
            }
        }

        if (!empty($action_link) && empty($error['action_logo'])) {

            if (!empty($menu_image)) {

                // create random image file name
                $string = '0123456789';
                $file = preg_replace("/\s+/", "_", $_FILES['action_logo']['name']);
                $function = new functions;
                $action_logo = $function-> $extension;

                // delete previous image
                $delete = unlink('upload/' . "$previous_category_image");

                // upload new image
                
                $upload = move_uploaded_file($_FILES['action_logo']['tmp_name'], 'upload/' . $menu_image);

                $sql_query = "UPDATE tbl_action
                                SET action_link = ?, action_logo = ?
                                WHERE cid = ?";

                $upload_image = get_abs_path() . 'upload/'.$menu_image . $action_logo;
                $stmt = $connect->stmt_init();
                if ($stmt->prepare($sql_query)) {
                    // Bind your variables to replace the ?s
                    $stmt->bind_param('sss',
                        $action_link,
                        $upload_image,
                        $ID);
                    // Execute query
                    $stmt->execute();
                    // store result
                    $update_result = $stmt->store_result();
                    $stmt->close();
                }
            } else {

                $sql_query = "UPDATE tbl_action
                                SET action_link = ?
                                WHERE cid = ?";

                $stmt = $connect->stmt_init();
                if ($stmt->prepare($sql_query)) {
                    // Bind your variables to replace the ?s
                    $stmt->bind_param('ss',
                        $action_link,
                        $ID);
                    // Execute query
                    $stmt->execute();
                    // store result
                    $update_result = $stmt->store_result();
                    $stmt->close();
                }
            }

            // check update result
            if ($update_result) {
                $error['update_action'] = "<div class='card-panel teal lighten-2'>
                                                        <span class='white-text text-darken-2'>
                                                            Website Successfully Updated...
                                                        </span>
                                                    </div>";
            } else {
                $error['update_action'] = "<div class='card-panel red darken-1'>
                                                        <span class='white-text text-darken-2'>
                                                            Update Failed
                                                        </span>
                                                    </div>";
            }
        }

    }

    // create array variable to store previous data
    $data = array();

    $sql_query = "SELECT *
                    FROM tbl_action
                    WHERE cid = ?";

    $stmt = $connect->stmt_init();
    if ($stmt->prepare($sql_query)) {
        // Bind your variables to replace the ?s
        $stmt->bind_param('s', $ID);
        // Execute query
        $stmt->execute();
        // store result
        $stmt->store_result();
        $stmt->bind_result($data['cid'],
            $data['action_link'],
            $data['action_logo']
        );
        $stmt->fetch();
        $stmt->close();
    }

    if (isset($_POST['btnCancel'])) {
        header("location: action.php");
    }

?>

    <!-- START CONTENT -->
    <section id="content">

        <!--breadcrumbs start-->
        <div id="breadcrumbs-wrapper" class=" grey lighten-3">
            <div class="container">
                <div class="row">
                    <div class="col s12 m12 l12">
                        <h5 class="breadcrumbs-title">Edit action</h5>
                        <ol class="breadcrumb">
                            <li><a href="dashboard.php">Dashboard</a></li>
                            <li><a href="action.php">Manage action</a></li>
                            <li><a class="active">Edit action</a></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <!--breadcrumbs end-->

        <!--start container-->
        <div class="container">
            <div class="section">
                <div class="row">
                    <div class="col s12 m12 l12">
                        <div class="card-panel">
                            <div class="row">
                                <form method="post" class="col s12" enctype="multipart/form-data">
                                    <div class="row">
                                        <div class="input-field col s12">
                                            <?php echo isset($error['update_action']) ? $error['update_action'] : ''; ?>

                                            <div class="row">
                                                <div class="input-field col s12">
                                                    <input type="url" name="action_link" id="action_link"
                                                           value="<?php echo $data['action_link']; ?>" required/>
                                                    <label for="action_link">Website Link:</label><?php echo isset($error['action_link']) ? $error['action_link'] : ''; ?>
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="input-field col s12 m12 l5">
                                                    <input type="file" name="action_logo" id="action_logo"
                                                           class="dropify-image" data-max-file-size="1M"
                                                           data-allowed-file-extensions="jpg png gif"
                                                           data-default-file="<?php echo $data['action_logo']; ?>"
                                                           data-show-remove="false"/>
                                                    <div class="div-error"><?php echo isset($error['action_logo']) ? $error['action_logo'] : ''; ?></div>
                                                </div>
                                            </div>

                                            <button class="btn cyan waves-effect waves-light right"
                                                    type="submit" name="btnEdit">Update
                                                <i class="mdi-content-send right"></i>
                                            </button>

                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
