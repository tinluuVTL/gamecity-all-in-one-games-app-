<?php include('session.php'); ?>
<?php include('public/menubar.php'); ?>
<?php include('public/add-adventure-form.php'); ?>
<?php include('public/footer.php'); ?>

<script type="text/javascript" src="assets/js/jquery.validate.min.js"></script>
<script type="text/javascript">

    (function($,W,D) {
        var JQUERY4U = {};
        JQUERY4U.UTIL = {
            setupFormValidation: function() {
                //form validation rules
                $("#form-validation").validate({
                    rules: {
                        adventure_name  : "required",
                        adventure_link  : "required",
                        adventure_logo  : "required"
                    },

                    messages: {
                        adventure_name  : "Please insert a valid name!",
                        adventure_link  : "Please insert a valid link!",
                        adventure_logo  : "Please fill out this field!"

                    },
                    errorElement : 'div',
                    submitHandler: function(form) {
                        form.submit();
                    }

                });
            }
        }

        //when the dom has loaded setup form validation rules
        $(D).ready(function($) {
            JQUERY4U.UTIL.setupFormValidation();
        });

    })(jQuery, window, document);

</script>